//Requisição XMLDocument
$(function(){
	$("#ajax").click(function(){
		$.ajax({
			type: "GET",
			url: "./Aula12 -Material/file.xml",
			dataType: "xml",
			success: function(xml){
				var formando = xml.getElementsByTagName("formando");
				for(var i = 0;i < formando.length;i++)
					document.write(formando[i].lastChild.nodeValue);
				/*$(xml).find('formacao').each(function(){
					$(this).find('formando').each(function(){
						var name = $(this).text();
						document.write(name);
					});
					document.write("<br />");
				});*/
			}
		});
		return false;
	});
});










