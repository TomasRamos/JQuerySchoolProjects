$(document).ready(function(){
	//$(":input").css("background","#cdcd00");
	//$(":text").css("background","#cdcd00");
	$(":button").click(function(){
		//$(":text").css("background","#cdcd00");
		//$(":password").css("background","#cdcd00");
		//$(":radio").parent().css("background","#cdcd00");
		//$(":checkbox").parent().css("background","#cdcd00");
			$(":selected").next().css("background","#cdcd00");
	}).css("border","2px solid #ff00fc");
});











