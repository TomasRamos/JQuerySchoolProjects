//Requisição XMLDocument
$(function(){
	$('.obrigatorio').valueOf('alert("Parametros obrigatórios em falta")');
});










