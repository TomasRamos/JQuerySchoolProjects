$(document).ready(function(){
	//$("*").css("color","#0000ff");
	//$("#nome").css("color","#0000ff");
	//$(".p3").css("color","#0000ff");
	//$("span").css("color","#0000ff");
	//$(".p3,span").css("color","#0000ff");
	//$("p span").css("color","#0000ff");
	//$("p > span").css("border","1px solid #ff0000");
	//$(".p3 + span").css("border","1px solid #ff00ff");
	//$("#nome + p").css("border","1px solid #ff0000");
	//$("p + span").css("border","1px solid #ff0000");
	//$("#nome ~ p").css("border","1px solid #ff0000");
	//$("*").css("background","#00cdcd");
	//$("p span").css("background","#cdcdcd");
	//$("p span:first").css("background","#00cdcd");
	//$("p span:last").css("background","#00cdcd");
	//$("p span:not(p span:first)").css("background","#cdcd00");
	//$("p span:even").css("background","#cd00cd");
	//$("p span:odd").css("background","#cd00cd");
	//$("p span:eq(1)").css("background","#cd00cd");
	//$("p span:gt(0)").css("background","#cd00cd");
	//$("p span:lt(2)").css("background","#cd00cd");
	//$("p:contains(Tomás)").css("background","#cd00cd");
	//$("p:empty").css("background","#cd00cd");
	//$("p:not(p:empty)").css("background","#cd00cd");
	//$("p:has(span)").css("background","#cdcd00");
	//$("a[id]").css("background","#cdcd00");
	//$("a[id=email]").css("background","#cdcd00");
	//$("a[id*=e]").css("background","#cdcd00");
	//$("a[href$=rar]").css("background","#cdcd00");
	//$("a[href^=http]").css("background","#cdcd00");
	$("a[id!=google]").css("background","#cdcd00");
});












